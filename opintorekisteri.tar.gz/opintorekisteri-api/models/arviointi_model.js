const db = require("../db");

const arviointi = {

getAll(callback){
 return db.query("SELECT * FROM Arviointi", callback);
},

getOne(id,callback){
 return db.query("SELECT * FROM Arviointi WHERE id_arviointi=?", [id], callback);
},

add(data,callback){
 return db.query(
  "INSERT INTO Arviointi(opiskelija_id,opintojakso_id,arvosana,suorituspvm) VALUES(?,?,?,?)",
  [data.opiskelija_id,data.opintojakso_id,data.arvosana,data.suorituspvm],
  callback
 );
},

update(id,data,callback){
 return db.query(
  "UPDATE Arviointi SET opiskelija_id=?,opintojakso_id=?,arvosana=?,suorituspvm=? WHERE id_arviointi=?",
  [data.opiskelija_id,data.opintojakso_id,data.arvosana,data.suorituspvm,id],
  callback
 );
},

delete(id,callback){
 return db.query(
  "DELETE FROM Arviointi WHERE id_arviointi=?",
  [id],
  callback
 );
}

};

module.exports = arviointi;