const express = require("express");
const router = express.Router();
const user = require("../models/user_model");

router.get("/",function(req,res){
 user.getAll(function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.get("/:username",function(req,res){
 user.getOne(req.params.username,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/",function(req,res){
 user.add(req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.put("/:username",function(req,res){
 user.update(req.params.username,req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.delete("/:username",function(req,res){
 user.delete(req.params.username,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/authenticate",function(req,res){
 user.authenticate(req.body.username,req.body.password,function(err,result){
  if(err) res.json(err);
  else res.json({authenticated: result});
 });
});

module.exports = router;