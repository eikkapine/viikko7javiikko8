const db = require("../db");
const bcrypt = require("bcryptjs");

const user = {

getAll(callback){
 return db.query("SELECT username,password FROM user", callback);
},

getOne(username,callback){
 return db.query("SELECT username,password FROM user WHERE username=?", [username], callback);
},

add(data,callback){
 bcrypt.hash(data.password, 10, function(err, hash) {
  if(err) return callback(err);
  return db.query(
   "INSERT INTO user(username,password) VALUES(?,?)",
   [data.username,hash],
   callback
  );
 });
},

update(username,data,callback){
 bcrypt.hash(data.password, 10, function(err, hash) {
  if(err) return callback(err);
  return db.query(
   "UPDATE user SET password=? WHERE username=?",
   [hash,username],
   callback
  );
 });
},

delete(username,callback){
 return db.query(
  "DELETE FROM user WHERE username=?",
  [username],
  callback
 );
},

authenticate(username,password,callback){
 user.getOne(username,function(err,result){
  if(err) return callback(err);
  if(result.length === 0) return callback(null,false);
  bcrypt.compare(password, result[0].password, function(err, isMatch) {
   if(err) return callback(err);
   callback(null, isMatch);
  });
 });
}

};

module.exports = user;