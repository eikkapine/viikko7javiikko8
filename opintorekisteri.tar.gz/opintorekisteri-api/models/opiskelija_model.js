const db = require("../db");

const opiskelija = {

getAll(callback){
 return db.query("SELECT * FROM Opiskelija", callback);
},

getOne(id,callback){
 return db.query("SELECT * FROM Opiskelija WHERE id_opiskelija=?", [id], callback);
},

add(data,callback){
 return db.query(
  "INSERT INTO Opiskelija(etunimi,sukunimi,opiskelijanumero) VALUES(?,?,?)",
  [data.etunimi,data.sukunimi,data.opiskelijanumero],
  callback
 );
},

update(id,data,callback){
 return db.query(
  "UPDATE Opiskelija SET etunimi=?,sukunimi=?,opiskelijanumero=? WHERE id_opiskelija=?",
  [data.etunimi,data.sukunimi,data.opiskelijanumero,id],
  callback
 );
},

delete(id,callback){
 return db.query(
  "DELETE FROM Opiskelija WHERE id_opiskelija=?",
  [id],
  callback
 );
}

};

module.exports = opiskelija;