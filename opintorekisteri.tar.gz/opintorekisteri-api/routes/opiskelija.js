const express = require("express");
const router = express.Router();
const opiskelija = require("../models/opiskelija_model");

router.get("/",function(req,res){
 opiskelija.getAll(function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.get("/:id",function(req,res){
 opiskelija.getOne(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/",function(req,res){
 opiskelija.add(req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.put("/:id",function(req,res){
 opiskelija.update(req.params.id,req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.delete("/:id",function(req,res){
 opiskelija.delete(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

module.exports = router;