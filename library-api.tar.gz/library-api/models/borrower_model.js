const db = require("../db");

const borrower = {

getAll(callback){
 return db.query("SELECT * FROM borrower", callback);
},

getOne(id,callback){
 return db.query("SELECT * FROM borrower WHERE id_borrower=?", [id], callback);
},

add(data,callback){
 return db.query(
  "INSERT INTO borrower(fname,lname,streetaddress) VALUES(?,?,?)",
  [data.fname,data.lname,data.streetaddress],
  callback
 );
},

update(id,data,callback){
 return db.query(
  "UPDATE borrower SET fname=?,lname=?,streetaddress=? WHERE id_borrower=?",
  [data.fname,data.lname,data.streetaddress,id],
  callback
 );
},

delete(id,callback){
 return db.query(
  "DELETE FROM borrower WHERE id_borrower=?",
  [id],
  callback
 );
}

};

module.exports = borrower;