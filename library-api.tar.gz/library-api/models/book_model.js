const db = require("../db");

const book = {

getAll(callback){
 return db.query("SELECT * FROM book", callback);
},

getOne(id,callback){
 return db.query("SELECT * FROM book WHERE id_book=?", [id], callback);
},

add(data,callback){
 return db.query(
  "INSERT INTO book(name,author,isbn) VALUES(?,?,?)",
  [data.name,data.author,data.isbn],
  callback
 );
},

update(id,data,callback){
 return db.query(
  "UPDATE book SET name=?,author=?,isbn=? WHERE id_book=?",
  [data.name,data.author,data.isbn,id],
  callback
 );
},

delete(id,callback){
 return db.query(
  "DELETE FROM book WHERE id_book=?",
  [id],
  callback
 );
}

};

module.exports = book;