const express = require("express");
const router = express.Router();
const arviointi = require("../models/arviointi_model");

router.get("/",function(req,res){
 arviointi.getAll(function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.get("/:id",function(req,res){
 arviointi.getOne(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/",function(req,res){
 arviointi.add(req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.put("/:id",function(req,res){
 arviointi.update(req.params.id,req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.delete("/:id",function(req,res){
 arviointi.delete(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

module.exports = router;