const db = require("../db");

const opintojakso = {

getAll(callback){
 return db.query("SELECT * FROM Opintojakso", callback);
},

getOne(id,callback){
 return db.query("SELECT * FROM Opintojakso WHERE id_opintojakso=?", [id], callback);
},

add(data,callback){
 return db.query(
  "INSERT INTO Opintojakso(nimi,koodi,laajuus) VALUES(?,?,?)",
  [data.nimi,data.koodi,data.laajuus],
  callback
 );
},

update(id,data,callback){
 return db.query(
  "UPDATE Opintojakso SET nimi=?,koodi=?,laajuus=? WHERE id_opintojakso=?",
  [data.nimi,data.koodi,data.laajuus,id],
  callback
 );
},

delete(id,callback){
 return db.query(
  "DELETE FROM Opintojakso WHERE id_opintojakso=?",
  [id],
  callback
 );
}

};

module.exports = opintojakso;