const express = require("express");
const router = express.Router();
const opintojakso = require("../models/opintojakso_model");

router.get("/",function(req,res){
 opintojakso.getAll(function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.get("/:id",function(req,res){
 opintojakso.getOne(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/",function(req,res){
 opintojakso.add(req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.put("/:id",function(req,res){
 opintojakso.update(req.params.id,req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.delete("/:id",function(req,res){
 opintojakso.delete(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

module.exports = router;