const express = require("express");
const router = express.Router();
const book = require("../models/book_model");

router.get("/",function(req,res){
 book.getAll(function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.get("/:id",function(req,res){
 book.getOne(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/",function(req,res){
 book.add(req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.put("/:id",function(req,res){
 book.update(req.params.id,req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.delete("/:id",function(req,res){
 book.delete(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

module.exports = router;