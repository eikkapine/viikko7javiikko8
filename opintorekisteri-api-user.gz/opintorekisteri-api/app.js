const express = require("express");
const cors = require("cors");

const opiskelijaRoutes = require("./routes/opiskelija");
const opintojaksoRoutes = require("./routes/opintojakso");
const arviointiRoutes = require("./routes/arviointi");
const userRoutes = require("./routes/user");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/opiskelija",opiskelijaRoutes);
app.use("/opintojakso",opintojaksoRoutes);
app.use("/arviointi",arviointiRoutes);
app.use("/user",userRoutes);

app.listen(3001,function(){
 console.log("Server running on port 3001");
});