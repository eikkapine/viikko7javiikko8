const express = require("express");
const cors = require("cors");

const bookRoutes = require("./routes/book");
const borrowerRoutes = require("./routes/borrower");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/book",bookRoutes);
app.use("/borrower",borrowerRoutes);

app.listen(3000,function(){
 console.log("Server running on port 3000");
});