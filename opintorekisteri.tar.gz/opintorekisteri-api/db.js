const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "KOIRAT!1312?",
    database: "opintorekisteri"
});

connection.connect(function(err){
    if(err) throw err;
    console.log("MySQL connected");
});

module.exports = connection;