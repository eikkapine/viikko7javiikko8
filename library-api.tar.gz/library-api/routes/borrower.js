const express = require("express");
const router = express.Router();
const borrower = require("../models/borrower_model");

router.get("/",function(req,res){
 borrower.getAll(function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.get("/:id",function(req,res){
 borrower.getOne(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.post("/",function(req,res){
 borrower.add(req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.put("/:id",function(req,res){
 borrower.update(req.params.id,req.body,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

router.delete("/:id",function(req,res){
 borrower.delete(req.params.id,function(err,result){
  if(err) res.json(err);
  else res.json(result);
 });
});

module.exports = router;